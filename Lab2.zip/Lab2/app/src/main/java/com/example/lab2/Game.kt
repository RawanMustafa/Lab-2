package com.example.lab2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_game.*
import java.util.*

class Game : AppCompatActivity() {

    var diceCounters = IntArray(6)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        updateResult()
        diceImageButton.setOnClickListener {
            val diceNumber = Random().nextInt((6 + 1) - 1) + 1;
            diceCounters[diceNumber - 1] = diceCounters[diceNumber - 1] + 1

            diceImageButton.setImageResource(
                resources.getIdentifier(
                    "dice" + diceNumber,
                    "drawable",
                    this.packageName
                )
            )
            updateResult()
        }
        resetButton.setOnClickListener {
            diceCounters = IntArray(6)
            updateResult()
        }
    }

    private fun updateResult() {
        var result = ""
        for ((index, value) in diceCounters.withIndex()) {
            result = result + (index + 1).toString() + ":" + value.toString() + "\n"
        }
        resultTextView.setText(result)
    }
}