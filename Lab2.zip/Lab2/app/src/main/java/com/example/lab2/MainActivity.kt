package com.example.lab2

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startGameButton.setOnClickListener {
            val intent = Intent(this, Game::class.java)
            startActivity(intent)
        }
        quitGameButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Are you sure you want to quit?")
                .setPositiveButton(
                    "YES",
                    DialogInterface.OnClickListener { dialog, id -> finish() })
                .setNegativeButton(
                    "NO",
                    DialogInterface.OnClickListener { dialog, id -> dialog.dismiss() })
                .create().show()
        }

    }
}
